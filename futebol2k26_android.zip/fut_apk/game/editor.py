from .data import *


def show_team(t):
    print(f"\n{t['name']}")
    for i, p in enumerate(t["players"], 1):
        print(f"  {i:>2}. {p['pos']:<3} {p['name']:<20} OVR {p['ovr']:>2}  idade {p['age']}")


def editor():
    teams = load_league()
    while True:
        print("\n=== MODO EDITAR ===\n1. Editar time\n2. Restaurar padrao\n3. Salvar e voltar")
        op = ask_int("> ", 1, 3)
        if op == 3:
            save_league(teams)
            print("Salvo!")
            return
        if op == 2:
            teams = default_league()
            print("Times restaurados (salve para aplicar).")
            continue
        t = teams[pick_team(teams)]
        while True:
            show_team(t)
            print("\n1. Renomear time  2. Editar jogador  3. Voltar")
            o = ask_int("> ", 1, 3)
            if o == 3:
                break
            if o == 1:
                n = input("Novo nome: ").strip()
                if n:
                    t["name"] = n
            else:
                p = t["players"][ask_int("Numero do jogador: ", 1, len(t["players"])) - 1]
                n = input(f"Nome [{p['name']}]: ").strip()
                if n:
                    p["name"] = n
                p["ovr"] = ask_int(f"OVR (40-99) [{p['ovr']}]: ", 40, 99)
                p["age"] = ask_int(f"Idade (16-42) [{p['age']}]: ", 16, 42)
