import json, os, random

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SAVE_DIR = os.environ.get("FUT_SAVE_DIR", os.path.join(BASE, "saves"))
CUSTOM = os.path.join(SAVE_DIR, "custom.json")
os.makedirs(SAVE_DIR, exist_ok=True)

POS = ["GK", "DEF", "MID", "ATT"]
SQUAD = {"GK": 2, "DEF": 5, "MID": 5, "ATT": 4}
FIRST = ["Lucas", "Mateus", "Rafael", "Thiago", "Bruno", "Diego", "Caio", "Felipe", "Gabriel",
         "Andre", "Hugo", "Marco", "Pablo", "Nico", "Leo", "Davi", "Igor", "Renan", "Tomas", "Vitor"]
LAST = ["Silva", "Costa", "Rocha", "Lima", "Duarte", "Moraes", "Pires", "Nunes", "Ramos", "Torres",
        "Campos", "Vidal", "Freitas", "Barros", "Cardoso", "Teixeira", "Araujo", "Borges", "Melo", "Salgado"]
TEAMS = [("Aurora FC", 76), ("Real Cometa", 74), ("Atletico Tempestade", 72), ("Sporting Vale Verde", 70),
         ("Uniao Litoral", 68), ("Estrela do Norte", 66), ("Inter Montanha", 64), ("Racing Pampa", 62)]


def clamp(v, lo=40, hi=99):
    return max(lo, min(hi, v))


def new_player(pos, base):
    return {"name": f"{random.choice(FIRST)} {random.choice(LAST)}", "pos": pos,
            "ovr": clamp(base + random.randint(-8, 8)), "age": random.randint(18, 35)}


def make_team(name, base):
    players = []
    for pos, n in SQUAD.items():
        players += [new_player(pos, base) for _ in range(n)]
    return {"name": name, "players": players, "budget": 5000}


def default_league():
    return [make_team(n, b) for n, b in TEAMS]


def load_league():
    if os.path.exists(CUSTOM):
        with open(CUSTOM, encoding="utf-8") as f:
            return json.load(f)
    return default_league()


def save_league(teams):
    with open(CUSTOM, "w", encoding="utf-8") as f:
        json.dump(teams, f, ensure_ascii=False, indent=1)


def team_ovr(team):
    from .match import lineup
    l = lineup(team)
    return round(sum(p["ovr"] for p in l) / len(l))


def ask_int(prompt, lo, hi):
    while True:
        s = input(prompt).strip()
        if s.lstrip("-").isdigit() and lo <= int(s) <= hi:
            return int(s)
        print(f"  Digite um numero entre {lo} e {hi}.")


def pick_team(teams, prompt="Escolha o time: "):
    for i, t in enumerate(teams, 1):
        print(f"  {i}. {t['name']:<22} OVR {team_ovr(t)}")
    return ask_int(prompt, 1, len(teams)) - 1
