import json, os, random
from .data import *
from .match import simulate
from .editor import show_team


def fixtures(n):
    arr, rounds = list(range(n)), []
    for r in range(n - 1):
        pairs = [(arr[i], arr[n - 1 - i]) for i in range(n // 2)]
        rounds.append(pairs if r % 2 == 0 else [(b, a) for a, b in pairs])
        arr = [arr[0]] + [arr[-1]] + arr[1:-1]
    return rounds + [[(b, a) for a, b in r] for r in rounds]


def blank_table(n):
    return {str(i): dict(p=0, w=0, d=0, l=0, gf=0, ga=0, pts=0) for i in range(n)}


def new_season(c):
    c["fix"] = fixtures(len(c["teams"]))
    random.shuffle(c["fix"])
    c["round"], c["table"] = 0, blank_table(len(c["teams"]))


def record(c, h, a, gh, ga):
    for i, gf, gc in ((h, gh, ga), (a, ga, gh)):
        r = c["table"][str(i)]
        r["p"] += 1; r["gf"] += gf; r["ga"] += gc
        if gf > gc: r["w"] += 1; r["pts"] += 3
        elif gf == gc: r["d"] += 1; r["pts"] += 1
        else: r["l"] += 1


def standings(c):
    return sorted(c["table"].items(), key=lambda kv: (-kv[1]["pts"], -(kv[1]["gf"] - kv[1]["ga"]), -kv[1]["gf"]))


def show_table(c):
    print(f"\n  {'#':<3}{'Time':<22}{'P':>3}{'V':>3}{'E':>3}{'D':>3}{'SG':>4}{'Pts':>5}")
    for pos, (i, r) in enumerate(standings(c), 1):
        mark = "*" if int(i) == c["user"] else " "
        print(f"{mark} {pos:<3}{c['teams'][int(i)]['name']:<22}{r['p']:>3}{r['w']:>3}{r['d']:>3}{r['l']:>3}"
              f"{r['gf']-r['ga']:>4}{r['pts']:>5}")


def price(p):
    return max(100, (p["ovr"] - 55) ** 2 * 5)


def play_round(c):
    u = c["user"]
    for h, a in c["fix"][c["round"]]:
        if u in (h, a):
            res = simulate(c["teams"][h], c["teams"][a], True, 0.05)
        else:
            res = simulate(c["teams"][h], c["teams"][a], False)
        gh, ga = res["goals"]
        record(c, h, a, gh, ga)
        if u in (h, a):
            mine, opp = (gh, ga) if u == h else (ga, gh)
            c["teams"][u]["budget"] += 300 if mine > opp else 100 if mine == opp else 50
        else:
            print(f"  {c['teams'][h]['name']} {gh} x {ga} {c['teams'][a]['name']}")
    c["round"] += 1


def end_season(c):
    st = standings(c)
    champ = c["teams"][int(st[0][0])]["name"]
    pos = [int(i) for i, _ in st].index(c["user"]) + 1
    print(f"\n*** FIM DA TEMPORADA {c['season']} ***\nCampeao: {champ}\nSua posicao: {pos}o")
    prize = max(0, (9 - pos) * 400)
    c["teams"][c["user"]]["budget"] += prize
    print(f"Premio: {prize} mil")
    for t in c["teams"]:
        for p in t["players"]:
            p["age"] += 1
            p["ovr"] = clamp(p["ovr"] + (random.randint(0, 3) if p["age"] < 25 else
                                         random.randint(-1, 1) if p["age"] < 31 else random.randint(-3, 0)))
    c["season"] += 1
    new_season(c)


def training(c):
    t = c["teams"][c["user"]]
    show_team(t)
    print(f"Orcamento: {t['budget']} mil | Treino custa 100 mil (0 para voltar)")
    n = ask_int("Jogador: ", 0, len(t["players"]))
    if n == 0 or t["budget"] < 100:
        return
    p = t["players"][n - 1]
    t["budget"] -= 100
    g = random.randint(0, 3) if p["age"] <= 25 else random.randint(0, 2)
    p["ovr"] = clamp(p["ovr"] + g)
    print(f"{p['name']} evoluiu +{g} (OVR {p['ovr']})")


def transfers(c):
    t = c["teams"][c["user"]]
    while True:
        print(f"\n1. Comprar  2. Vender  3. Voltar  (orcamento {t['budget']} mil)")
        op = ask_int("> ", 1, 3)
        if op == 3:
            return
        if op == 1:
            mk = [new_player(random.choice(POS), random.randint(55, 82)) for _ in range(6)]
            for i, p in enumerate(mk, 1):
                print(f"  {i}. {p['pos']:<3} {p['name']:<20} OVR {p['ovr']} idade {p['age']}  {price(p)} mil")
            n = ask_int("Comprar (0 cancela): ", 0, 6)
            if n and t["budget"] >= price(mk[n - 1]):
                t["budget"] -= price(mk[n - 1]); t["players"].append(mk[n - 1]); print("Contratado!")
            elif n:
                print("Sem dinheiro.")
        else:
            show_team(t)
            n = ask_int("Vender (0 cancela): ", 0, len(t["players"]))
            if not n:
                continue
            p = t["players"][n - 1]
            if sum(1 for x in t["players"] if x["pos"] == p["pos"]) <= {"GK": 1, "DEF": 4, "MID": 4, "ATT": 2}[p["pos"]]:
                print("Elenco ficaria incompleto nessa posicao.")
                continue
            t["budget"] += int(price(p) * 0.7); t["players"].remove(p); print("Vendido!")


def save(c):
    with open(os.path.join(SAVE_DIR, "carreira.json"), "w", encoding="utf-8") as f:
        json.dump(c, f, ensure_ascii=False)
    print("Carreira salva!")


def career():
    path = os.path.join(SAVE_DIR, "carreira.json")
    c = None
    print("\n=== MODO CARREIRA ===\n1. Nova carreira\n2. Continuar\n3. Voltar")
    op = ask_int("> ", 1, 3)
    if op == 3:
        return
    if op == 2:
        if not os.path.exists(path):
            print("Nenhum save encontrado."); return
        with open(path, encoding="utf-8") as f:
            c = json.load(f)
    else:
        teams = load_league()
        c = {"teams": teams, "user": pick_team(teams, "Seu clube: "), "season": 1}
        new_season(c)
    while True:
        t = c["teams"][c["user"]]
        print(f"\n--- {t['name']} | Temporada {c['season']} | Rodada {c['round']+1}/{len(c['fix'])} | {t['budget']} mil ---")
        print("1. Jogar proxima rodada  2. Tabela  3. Elenco  4. Treinar  5. Mercado  6. Salvar  7. Sair")
        op = ask_int("> ", 1, 7)
        if op == 1:
            play_round(c)
            if c["round"] >= len(c["fix"]):
                end_season(c)
        elif op == 2: show_table(c)
        elif op == 3: show_team(t)
        elif op == 4: training(c)
        elif op == 5: transfers(c)
        elif op == 6: save(c)
        else: return
