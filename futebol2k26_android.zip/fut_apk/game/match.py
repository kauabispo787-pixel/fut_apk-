import random, time

FORMATION = {"GK": 1, "DEF": 4, "MID": 4, "ATT": 2}


def lineup(team):
    res = []
    for pos, n in FORMATION.items():
        ps = sorted([p for p in team["players"] if p["pos"] == pos], key=lambda p: -p["ovr"])
        res += ps[:n]
    return res


def avg(l):
    return sum(l) / len(l) if l else 50


def strengths(team):
    l = lineup(team)
    g = lambda pos: [p["ovr"] for p in l if p["pos"] == pos]
    return {"att": avg(g("ATT")) * 0.6 + avg(g("MID")) * 0.4,
            "mid": avg(g("MID")),
            "def": avg(g("DEF")) * 0.7 + avg(g("GK")) * 0.3,
            "gk": avg(g("GK")), "lineup": l}


def simulate(home, away, verbose=True, delay=0.0):
    S = {0: strengths(home), 1: strengths(away)}
    S[0]["mid"] += 3  # fator casa
    names = [home["name"], away["name"]]
    goals, shots, target, cards, poss = [0, 0], [0, 0], [0, 0], [0, 0], [0, 0]
    events = []

    def say(txt):
        events.append(txt)
        if verbose:
            print(txt)
            if delay:
                time.sleep(delay)

    say(f"\n=== {names[0]} x {names[1]} ===  Apito inicial!")
    for minute in range(1, 91):
        total = S[0]["mid"] + S[1]["mid"]
        side = 0 if random.random() < S[0]["mid"] / total else 1
        poss[side] += 1
        o, d = S[side], S[1 - side]
        if random.random() > 0.15 + (o["att"] - d["def"]) / 400:
            if random.random() < 0.012:
                v = random.choice(S[1 - side]["lineup"])
                cards[1 - side] += 1
                say(f"{minute:>2}' Cartao amarelo para {v['name']} ({names[1 - side]})")
            continue
        w = [{"ATT": 50, "MID": 30, "DEF": 6, "GK": 0}[p["pos"]] for p in o["lineup"]]
        shooter = random.choices(o["lineup"], weights=w)[0]
        shots[side] += 1
        on = 0.38 + (shooter["ovr"] - d["def"]) / 200
        if random.random() > max(0.15, min(0.7, on)):
            say(f"{minute:>2}' {shooter['name']} ({names[side]}) chuta pra fora.")
            continue
        target[side] += 1
        gk = max(d["lineup"][0]["ovr"], 1)
        pg = max(0.08, min(0.6, 0.30 + (shooter["ovr"] - gk) / 150))
        if random.random() < pg:
            goals[side] += 1
            say(f"{minute:>2}' GOOOL! {shooter['name']} ({names[side]})  [{goals[0]}-{goals[1]}]")
        else:
            say(f"{minute:>2}' {d['lineup'][0]['name']} faz grande defesa!")
        if minute == 45:
            say("--- Intervalo ---")
    tp = max(1, sum(poss))
    say(f"\nFIM: {names[0]} {goals[0]} x {goals[1]} {names[1]}")
    if verbose:
        print(f"Posse: {poss[0]*100//tp}% - {poss[1]*100//tp}% | Chutes: {shots[0]}-{shots[1]} | "
              f"No gol: {target[0]}-{target[1]} | Cartoes: {cards[0]}-{cards[1]}")
    return {"goals": goals, "shots": shots, "events": events}
