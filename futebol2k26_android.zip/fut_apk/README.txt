FUTEBOL SIMULATOR 2K26 - VERSAO ANDROID (Kivy)

COMO GERAR O APK (escolha um):

A) GitHub (mais facil, sem instalar nada)
   1. Crie um repositorio no GitHub e envie o conteudo desta pasta.
   2. Aba "Actions" > "Build APK" > aguarde (~15-25 min).
   3. Baixe o artefato "futebol2k26-apk" (contem o .apk).

B) Linux / WSL / Google Colab
   pip install buildozer cython
   sudo apt install -y git zip unzip openjdk-17-jdk autoconf libtool pkg-config zlib1g-dev libncurses-dev libffi-dev libssl-dev
   buildozer android debug
   O APK fica em bin/.

Testar no PC antes:  pip install kivy  &&  python main.py
Para instalar no celular, permita "instalar apps de fontes desconhecidas".
