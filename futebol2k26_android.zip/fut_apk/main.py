"""Futebol Simulator 2K26 - versao Android (Kivy)."""
import io, json, os, random
from contextlib import redirect_stdout

from kivy.app import App
from kivy.clock import Clock
from kivy.metrics import dp
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.gridlayout import GridLayout
from kivy.uix.label import Label
from kivy.uix.popup import Popup
from kivy.uix.scrollview import ScrollView
from kivy.uix.textinput import TextInput


class FutApp(App):
    title = "Futebol Simulator 2K26"

    def build(self):
        os.environ["FUT_SAVE_DIR"] = self.user_data_dir
        os.makedirs(self.user_data_dir, exist_ok=True)
        global D, M, C, E
        from game import data as D, match as M, career as C, editor as E
        self.c = None
        self.timer = None
        root = BoxLayout(orientation="vertical", padding=dp(6), spacing=dp(6))
        self.out = Label(text="", size_hint_y=None, halign="left", valign="top",
                         font_name="RobotoMono-Regular", font_size="11sp")
        self.out.bind(width=lambda *_: setattr(self.out, "text_size", (self.out.width, None)),
                      texture_size=lambda *_: setattr(self.out, "height", self.out.texture_size[1] + dp(10)))
        self.sv = ScrollView(size_hint_y=0.55)
        self.sv.add_widget(self.out)
        self.btns = GridLayout(cols=1, size_hint_y=None, spacing=dp(4))
        self.btns.bind(minimum_height=self.btns.setter("height"))
        bsv = ScrollView(size_hint_y=0.45)
        bsv.add_widget(self.btns)
        root.add_widget(self.sv)
        root.add_widget(bsv)
        self.main_menu()
        return root

    # ---------- helpers de UI ----------
    def show(self, text):
        self.out.text = text
        self.sv.scroll_y = 1

    def menu(self, options):
        self.btns.clear_widgets()
        for label, cb in options:
            b = Button(text=label, size_hint_y=None, height=dp(46))
            b.bind(on_release=lambda _b, cb=cb: cb())
            self.btns.add_widget(b)

    def capture(self, fn, *a):
        buf = io.StringIO()
        with redirect_stdout(buf):
            fn(*a)
        return buf.getvalue()

    def form(self, title, fields, on_ok):
        box = BoxLayout(orientation="vertical", spacing=dp(6), padding=dp(8))
        inputs = {}
        for k, v in fields.items():
            box.add_widget(Label(text=k, size_hint_y=None, height=dp(24)))
            ti = TextInput(text=str(v), multiline=False, size_hint_y=None, height=dp(42))
            inputs[k] = ti
            box.add_widget(ti)
        row = BoxLayout(size_hint_y=None, height=dp(46), spacing=dp(8))
        pop = Popup(title=title, content=box, size_hint=(0.92, 0.6))
        ok, cancel = Button(text="OK"), Button(text="Cancelar")
        ok.bind(on_release=lambda *_: (pop.dismiss(), on_ok({k: t.text.strip() for k, t in inputs.items()})))
        cancel.bind(on_release=pop.dismiss)
        row.add_widget(ok); row.add_widget(cancel)
        box.add_widget(row)
        pop.open()

    def team_menu(self, teams, on_pick, back):
        self.menu([(f"{t['name']}  (OVR {D.team_ovr(t)})", lambda i=i: on_pick(i)) for i, t in enumerate(teams)]
                  + [("< Voltar", back)])

    def play_live(self, home, away, done):
        """Simula e mostra os lances aos poucos."""
        res = M.simulate(home, away, verbose=False)
        ev, shown = res["events"], []
        self.menu([("Pular animacao", lambda: finish())])
        it = iter(ev)

        def tick(dt):
            try:
                shown.append(next(it))
                self.out.text = "\n".join(shown[-60:])
                self.sv.scroll_y = 0
            except StopIteration:
                finish()

        def finish():
            if self.timer:
                self.timer.cancel(); self.timer = None
            self.out.text = "\n".join(ev)
            self.sv.scroll_y = 0
            done(res)

        self.timer = Clock.schedule_interval(tick, 0.12)

    # ---------- menu principal ----------
    def main_menu(self):
        self.show("FUTEBOL SIMULATOR 2K26\n\nEscolha um modo:")
        self.menu([("Amistoso", self.friendly), ("Carreira", self.career_menu),
                   ("Editar", self.editor_menu), ("Sair", self.stop)])

    # ---------- amistoso ----------
    def friendly(self):
        teams = D.load_league()
        self.show("AMISTOSO\n\nEscolha o time da CASA:")
        self.team_menu(teams, lambda h: self.friendly_away(teams, h), self.main_menu)

    def friendly_away(self, teams, h):
        self.show(f"Casa: {teams[h]['name']}\n\nEscolha o time VISITANTE:")
        self.team_menu(teams, lambda a: self.friendly_play(teams, h, a) if a != h else None,
                       self.friendly)

    def friendly_play(self, teams, h, a):
        self.play_live(teams[h], teams[a], lambda r: self.menu(
            [("Jogar de novo", lambda: self.friendly_play(teams, h, a)), ("Menu", self.main_menu)]))

    # ---------- carreira ----------
    def career_menu(self):
        self.show("CARREIRA")
        opts = [("Nova carreira", self.career_new)]
        if os.path.exists(os.path.join(D.SAVE_DIR, "carreira.json")):
            opts.append(("Continuar", self.career_load))
        self.menu(opts + [("< Voltar", self.main_menu)])

    def career_new(self):
        teams = D.load_league()
        self.show("Escolha seu clube:")

        def pick(i):
            self.c = {"teams": teams, "user": i, "season": 1}
            C.new_season(self.c)
            self.career_hub()
        self.team_menu(teams, pick, self.career_menu)

    def career_load(self):
        with open(os.path.join(D.SAVE_DIR, "carreira.json"), encoding="utf-8") as f:
            self.c = json.load(f)
        self.career_hub()

    def career_hub(self, msg=""):
        c = self.c
        t = c["teams"][c["user"]]
        self.show(f"{t['name']}\nTemporada {c['season']} | Rodada {c['round']+1}/{len(c['fix'])}\n"
                  f"Orcamento: {t['budget']} mil\n\n{msg}")
        self.menu([("Jogar proxima rodada", self.career_round), ("Tabela", self.career_table),
                   ("Elenco", self.career_squad), ("Treinar", self.career_train),
                   ("Mercado", self.career_market), ("Salvar", self.career_save),
                   ("Sair para o menu", self.main_menu)])

    def career_table(self):
        self.show(self.capture(C.show_table, self.c))
        self.menu([("< Voltar", self.career_hub)])

    def career_squad(self):
        self.show(self.capture(E.show_team, self.c["teams"][self.c["user"]]))
        self.menu([("< Voltar", self.career_hub)])

    def career_save(self):
        self.career_hub(self.capture(C.save, self.c))

    def career_round(self):
        c, u = self.c, self.c["user"]
        others = []
        mine = None
        for h, a in c["fix"][c["round"]]:
            if u in (h, a):
                mine = (h, a)
            else:
                g = M.simulate(c["teams"][h], c["teams"][a], False)["goals"]
                C.record(c, h, a, *g)
                others.append(f"{c['teams'][h]['name']} {g[0]} x {g[1]} {c['teams'][a]['name']}")
        h, a = mine

        def done(res):
            gh, ga = res["goals"]
            C.record(c, h, a, gh, ga)
            m, o = (gh, ga) if u == h else (ga, gh)
            c["teams"][u]["budget"] += 300 if m > o else 100 if m == o else 50
            c["round"] += 1
            txt = "\n".join(res["events"]) + "\n\nOutros jogos:\n" + "\n".join(others)
            if c["round"] >= len(c["fix"]):
                txt += "\n" + self.capture(C.end_season, c)
            self.show(txt)
            self.menu([("Continuar", self.career_hub)])
        self.play_live(c["teams"][h], c["teams"][a], done)

    def career_train(self):
        t = self.c["teams"][self.c["user"]]
        self.show(f"TREINO (100 mil cada)\nOrcamento: {t['budget']} mil\nEscolha o jogador:")

        def train(p):
            if t["budget"] < 100:
                return self.career_hub("Sem dinheiro.")
            t["budget"] -= 100
            g = random.randint(0, 3) if p["age"] <= 25 else random.randint(0, 2)
            p["ovr"] = D.clamp(p["ovr"] + g)
            self.career_hub(f"{p['name']} evoluiu +{g} (OVR {p['ovr']})")
        self.menu([(f"{p['pos']} {p['name']} OVR {p['ovr']}", lambda p=p: train(p)) for p in t["players"]]
                  + [("< Voltar", self.career_hub)])

    def career_market(self):
        t = self.c["teams"][self.c["user"]]
        self.show(f"MERCADO\nOrcamento: {t['budget']} mil")
        self.menu([("Comprar", self.market_buy), ("Vender", self.market_sell), ("< Voltar", self.career_hub)])

    def market_buy(self):
        t = self.c["teams"][self.c["user"]]
        mk = [D.new_player(random.choice(D.POS), random.randint(55, 82)) for _ in range(6)]
        self.show(f"Disponiveis para contratacao\nOrcamento: {t['budget']} mil")

        def buy(p):
            if t["budget"] < C.price(p):
                return self.show("Sem dinheiro.")
            t["budget"] -= C.price(p)
            t["players"].append(p)
            self.career_hub(f"{p['name']} contratado!")
        self.menu([(f"{p['pos']} {p['name']} OVR {p['ovr']} - {C.price(p)} mil", lambda p=p: buy(p)) for p in mk]
                  + [("< Voltar", self.career_market)])

    def market_sell(self):
        t = self.c["teams"][self.c["user"]]
        mins = {"GK": 1, "DEF": 4, "MID": 4, "ATT": 2}
        self.show("Quem voce quer vender? (70% do valor)")

        def sell(p):
            if sum(1 for x in t["players"] if x["pos"] == p["pos"]) <= mins[p["pos"]]:
                return self.show("Elenco ficaria incompleto nessa posicao.")
            t["budget"] += int(C.price(p) * 0.7)
            t["players"].remove(p)
            self.career_hub(f"{p['name']} vendido!")
        self.menu([(f"{p['pos']} {p['name']} OVR {p['ovr']}", lambda p=p: sell(p)) for p in t["players"]]
                  + [("< Voltar", self.career_market)])

    # ---------- editor ----------
    def editor_menu(self):
        self.teams = D.load_league()
        self.show("MODO EDITAR\n\nEscolha um time:")
        self.menu([(t["name"], lambda i=i: self.edit_team(i)) for i, t in enumerate(self.teams)]
                  + [("Restaurar padrao", self.edit_reset), ("< Voltar", self.main_menu)])

    def edit_reset(self):
        D.save_league(D.default_league())
        self.editor_menu()

    def edit_team(self, i):
        t = self.teams[i]
        self.show(f"Editando: {t['name']}")

        def rename():
            def ok(v):
                if v["Nome"]:
                    t["name"] = v["Nome"]; D.save_league(self.teams)
                self.edit_team(i)
            self.form("Renomear time", {"Nome": t["name"]}, ok)
        self.menu([("Renomear time", rename)]
                  + [(f"{p['pos']} {p['name']} OVR {p['ovr']}", lambda p=p: self.edit_player(i, p)) for p in t["players"]]
                  + [("< Voltar", self.editor_menu)])

    def edit_player(self, i, p):
        def ok(v):
            try:
                if v["Nome"]:
                    p["name"] = v["Nome"]
                p["ovr"] = max(40, min(99, int(v["OVR (40-99)"])))
                p["age"] = max(16, min(42, int(v["Idade (16-42)"])))
                D.save_league(self.teams)
            except ValueError:
                pass
            self.edit_team(i)
        self.form("Editar jogador", {"Nome": p["name"], "OVR (40-99)": p["ovr"], "Idade (16-42)": p["age"]}, ok)


if __name__ == "__main__":
    FutApp().run()
